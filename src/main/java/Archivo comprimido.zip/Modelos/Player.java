package Modelos;

public class Player {

    int x,y;

    public int getX(){
        return x;
    }

    public void setX(int X){
        this.x = x;
    }

    public int getY(){
        return y;
    }

    public void setY(int X){
        this.y = y;
    }

}
