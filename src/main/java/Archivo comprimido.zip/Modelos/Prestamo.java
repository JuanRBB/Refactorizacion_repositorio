package Modelos;

public class Prestamo {
}
